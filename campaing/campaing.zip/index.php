<?php
	require_once __DIR__.'/campaingcsrest_campaigns.php';
	require_once __DIR__.'/campaingcsrest_general.php';

	$authorize_url = CS_REST_General::authorize_url(
	    '114514',
	    'https://www.kmimos.com.mx/monitor_suscribir/correcto.php',
	    'ViewReports,ManageLists,CreateCampaigns,ImportSubscribers,SendCampaigns,ViewSubscribersInReports,ManageTemplates,AdministerPersons,AdministerAccount,ViewTransactional,SendTransactional'
	);

	echo $authorize_url;

	/*
?>

Your user is successfully authenticated. Here are the details you need:

access token: AUTr8b+NQpBPowMkSjArXeExNQ==
refresh token: AXsKGf+zs59Nq3zXbsnVx2ExNQ==
expires in: 1209600


We've made an API call too. Here are your clients:

array (
  0 => 
  stdClass::__set_state(array(
     'ClientID' => 'b7b62759c43ff163d0adb4872caeb3fe',
     'Name' => 'Kmimos',
  )),
  1 => 
  stdClass::__set_state(array(
     'ClientID' => '13b53e2879fc33a25dbb25091e7af180',
     'Name' => 'Kmimos Colombia',
  )),
  2 => 
  stdClass::__set_state(array(
     'ClientID' => '669439591f911be6263b52fdd7d2ff6c',
     'Name' => 'Kmimos Peru',
  )),
)

*/ ?>