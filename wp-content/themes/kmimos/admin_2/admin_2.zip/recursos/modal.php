<div class="modal">
	<div>
		<i id="close_modal" class="fa fa-times" aria-hidden="true"></i>
		<span></span>
		<div></div>
		<p></p>
	</div>
</div>