<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<style>
	@media screen and (max-width: 450px) {
		#fotos img {
			height: 100px !important;
		}
	}
</style>
<div style='text-align:center; margin-bottom: 34px;'>
    <img src='[URL_IMGS]/group-18.png' style='width: 100%;' >
</div>
<div style='padding: 0px;'>

	<div style='font-size: 14px; line-height: 1.07; letter-spacing: 0.3px; color: #000000;'>

		<div style='font-family: Arial; font-size: 20px; font-weight: bold; letter-spacing: 0.4px; color: #6b1c9b; padding-bottom: 10px;'>
			Hola [CLIENTE],
		</div>	
	    <div style='font-family: Arial; font-size: 14px; line-height: 1.14; letter-spacing: 0.3px; color: #000000; padding-bottom: 14px;'>
	    	Te compartimos las <strong>fotos que se tomaron durante el día</strong> de [MSG_PELUDOS], para que sepas lo bien que se la paso con <strong>[CUIDADOR]</strong>
	    </div>

	    <table cellpadding="0" cellspacing="0" style='margin-bottom: 21px; width: 580px;' >
		    <tr>
		        <td style='width: 360px; vertical-align: top;'>
		            <div style='font-family: Arial; font-size: 11px; letter-spacing: -0.1px;'>
		                FOTOS CARGADAS EL:
		            </div>                  
		            <div style='font-family: Arial; font-size: 16px; font-weight: bold; letter-spacing: 0.4px; color: #000000; margin-bottom: 2px;'>
		                27 de Octubre 2017 <span style='font-size: 14px; font-weight: normal;'>(21:35 PM)</span>
		            </div> 
		        </td>
		        <td style='width: 158px; vertical-align: top;'>
		            <div style='background-color: #f4f4f4; height: 50.3px; height: 50.3px; border-radius: 2.8px;'>
		                <div style='font-family: Arial; font-size: 12px; letter-spacing: 0.3px; color: #000000; padding: 10px 0px 0px 10px;'>
		                    Tu código de reserva es:
		                </div>
		                <div style='font-family: Arial; font-size: 14px; font-weight: bold; letter-spacing: 0px; color: #000000; padding: 3px 0px 0px 10px;'>
		                    [ID_RESERVA]
		                </div>
		            </div>
		        </td>
		    </tr>
		</table>

		<div id="fotos" style="max-width: 600px; margin: 0px auto 45px;">
			[FOTOS]
		</div>

		<div style="margin-bottom: 5px; text-align: center;">
			<a href="[URL_VER]" target="_blank"><img src="[URL_IMGS]/verlas.png" /></a>
		</div>

		<div style="margin-bottom: 30px; text-align: center;">
			<span style="font-family: Arial; font-size: 14px; letter-spacing: 0.2px; text-align: center; color: #666666;">(Si no logras visualizar las fotos por favor dale click)</span>
		</div>

	</div>

</div>