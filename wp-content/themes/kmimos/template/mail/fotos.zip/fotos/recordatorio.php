<div style='padding: 0px;'>

	<div style='font-size: 14px; line-height: 1.07; letter-spacing: 0.3px; color: #000000;'>

		<div style='font-family: Arial; font-size: 20px; font-weight: bold; letter-spacing: 0.4px; color: #6b1c9b; padding-bottom: 10px;'>
			Hola [CUIDADOR]
		</div>	
	    <div style='font-family: Arial; font-size: 14px; line-height: 1.07; letter-spacing: 0.3px; color: #000000; padding-bottom: 14px;'>
	    	Recuerda cargar a tiempo las fotos del periodo de la <strong>[PERIODO]</strong> para la reserva <strong>[ID_RESERVA]</strong>.
	    </div>

	</div>

</div>